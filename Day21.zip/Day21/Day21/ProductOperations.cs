﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class ProductOperations
    {
        static void Main(string[] args)
        {
            Products ob = new Products();
            ob.getdata();
            ob.printrecord();
        }
    }
}
