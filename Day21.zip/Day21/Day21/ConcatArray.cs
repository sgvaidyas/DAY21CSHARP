﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class ConcatArray
    {
        static void input(int[] a)
        {
            int n = a.Length;
            for(int i=0;i<n;i++)
                a[i] = Convert.ToInt32(Console.ReadLine());
        }
        static void Main(string[] args)
        {
            int n1, n2, n;
            Console.WriteLine("Enter the no of elements of array 1");
            n1 = Convert.ToInt32(Console.ReadLine());
            int[] a = new int[n1];

            Console.WriteLine("Enter the no of elements of array 2");
            n2 = Convert.ToInt32(Console.ReadLine());
            int[] b = new int[n2];

            Console.WriteLine("\n enter the elements of array 1");
            input(a);
            Console.WriteLine("\n enter the elements of array 2");
            input(b);

            //create third array with length = n1+n2
            int[] c = new int[n1 + n2];
            for (int i = 0; i < n1 + n2; i++)
                c[i] = (i<n1) ?  a[i]  : b[i-n1]  ;

            Console.WriteLine("\n the elements of array 3");
            for (int i = 0; i < n1 + n2; i++)
                Console.WriteLine(c[i]);
        }
    }
}
