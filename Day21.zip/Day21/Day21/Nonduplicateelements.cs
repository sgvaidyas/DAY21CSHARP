﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class Nonduplicateelements
    {
        static void Main(string[] args)
        {
            int[] a = { 11, 22, 3, 44, 5, 22, 44, 77 };
            int cnt;
            for(int i=0;i<a.Length;i++)
            {
                cnt = 0;
                for(int j=0;j<a.Length;j++)
                {
                    if(a[i] == a[j])
                    {
                        cnt++;
                        if (cnt > 1)
                            break;
                    }
                }
                if(cnt==1)
                    Console.WriteLine(a[i]);
            }
        }
    }
}
