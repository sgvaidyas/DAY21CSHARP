﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class Program
    {
        static void Main(string[] args)
        {
            int per;
            Console.WriteLine("Enter the percentage " );
            per = Convert.ToInt32(Console.ReadLine());

            switch((per>70)?"DIST":(per>50)?"FIRST":(per>35)?"PASS":"FAIL")
            {
                case "DIST": Console.WriteLine("DISTINCTION"); break;
                case "FIRST": Console.WriteLine("FIRST CLASS"); break;
                case "PASS": Console.WriteLine("PASSED"); break;
                case "FAIL": Console.WriteLine("FAILED"); break;
                default: Console.WriteLine("Invalid percent");break;
            }
        }
    }
}
