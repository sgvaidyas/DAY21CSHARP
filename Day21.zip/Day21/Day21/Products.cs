﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class Products
    {
        int pid;
        string name;
        float price;

        public void getdata()
        {
            Console.Write("Please enter the PID = ");
            pid = Convert.ToInt32(Console.ReadLine());
            Console.Write("Please enter the PNAME = ");
            name =Console.ReadLine();
            Console.Write("Please enter the PRICE = ");
            price = float.Parse(Console.ReadLine());
        }
        public void printrecord()
        {
            Console.WriteLine("PID     = " +pid);
            Console.WriteLine("NAME    = " + name);
            Console.WriteLine("PRICE   = " + price);
        }
    }
}
