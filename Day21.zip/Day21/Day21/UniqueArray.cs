﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class UniqueArray
    {
        static void Main(string[] args)
        {
            int[] a = { 1, 2, 3, 2, 1, 4, 5, 6, 5, 8 };
            int i, j;
            for(i=0; i<a.Length;i++)
            {
                for(j=0;j<i;j++)
                {
                    if (a[i] == a[j])
                        break;
                }
                if(i==j)
                    Console.WriteLine(a[i]);
            }

        }
    }
}
