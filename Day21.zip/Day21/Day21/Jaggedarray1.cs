﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class Jaggedarray1
    {
        static void Main(string[] args)
        {
            int rows;
            Console.WriteLine("Enter num of rows");
            rows = Convert.ToInt32(Console.ReadLine());
            int[][] a = new int[rows][];
            for(int i=0;i<rows;i++)
            {
                Console.WriteLine("Enter no of columns for {0} row",i);
                int col = Convert.ToInt32(Console.ReadLine());
                a[i] = new int[col];
            }            
            Console.WriteLine("PROVIDE INPUT ");
            for(int i=0;i<a.GetLength(0);i++)
            {
                for(int j=0;j<a[i].Length;j++)
                {
                    a[i][j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("PRINTING ARRAY ");
            for (int i = 0; i < a.GetLength(0); i++)
            {
                for (int j = 0; j < a[i].Length; j++)
                {
                    Console.Write(a[i][j] + " \t");    
                }
                Console.WriteLine();
            }
            int sum = 0;
            Console.WriteLine("\n SUM OF EACH ROW ARRAY ");
            for (int i = 0; i < a.GetLength(0); i++)
            {
                sum = 0;
                for (int j = 0; j < a[i].Length; j++)
                {
                    sum += a[i][j];
                }
                Console.WriteLine("the sum of {0} row = {1}",i,sum);
            }
        }
    }
}
