﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class MatchingElements
    {
        static void Main(string[] args)
        {
            
             int[] a = { 1, 2, 3, 4, 5 };
             int[] b = { 2, 3, 4, 8, 9 };

             var intersect = a.Intersect(b);
            int[] x = intersect.ToArray();
            Console.WriteLine(intersect);

             foreach(int v in x)
                 Console.WriteLine(v);
                
                /*
            int[] a = { 1, 2, 3, 4, 5 };
            int[] b = { 2, 3, 4, 8, 9, 55, 6 };
            Console.WriteLine("Common elements = ");
            for (int i = 0; i < a.Length; i++)
            {
                for (int j = 0; j < b.Length; j++)
                {
                    if (a[i] == b[j])
                        Console.WriteLine(a[i]);
                }
            }
            */

        }
    }
}
