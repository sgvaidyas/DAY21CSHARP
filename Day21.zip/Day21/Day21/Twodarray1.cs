﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day21
{
    class Twodarray1
    {
        static void input(int[,] a)
        {
            int rows = a.GetLength(0);
            int cols = a.GetLength(1);

            for(int i=0;i<rows;i++)
            {
                Console.WriteLine("Enter the elements of {0}th row ",i );
                for(int j=0;j<cols;j++)
                {
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
        }
        static void printArray(int[,] a)
        {
            Console.WriteLine("Total num of elements " + a.Length);
            int rows = a.GetLength(0);
            int cols = a.GetLength(1);

            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    Console.Write(a[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
        static void rowsum(int[,] a)
        {
            int rows = a.GetLength(0);
            int cols = a.GetLength(1);
            int sum = 0;
            for (int i = 0; i < rows; i++)
            {
                sum = 0;
                for (int j = 0; j < cols; j++)
                {
                    sum += a[i, j];
                }
                Console.WriteLine("sum of {0} row = {1}",i,sum);
            }
        }
        static void colsum(int[,] a)
        {
            int rows = a.GetLength(0);
            int cols = a.GetLength(1);
            int sum = 0;
            for (int j = 0; j < cols; j++)
            {
                sum = 0;
                for (int i = 0; i < rows; i++)
                {
                    sum += a[i, j];
                }
                Console.WriteLine("sum of {0} col = {1}", j, sum);
            }
        }

        static void sumdiagonal(int[,] a)
        {
            int rows = a.GetLength(0);
            int cols = a.GetLength(1);
            int sum = 0;
            for (int i = 0; i < rows; i++)
            {
                sum += a[i, i];
            }
            Console.WriteLine("the diagonal element sum = "+sum);
        }

        static void Main(string[] args)
        {
            int rows, cols;
            Console.Write("Enter no of rows = ");
            rows = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter no of cols = ");
            cols = Convert.ToInt32(Console.ReadLine());

            int[,] a = new int[rows, cols];
            input(a);
            printArray(a);
            Console.WriteLine("SUM OF ROWS\n");
            rowsum(a);
            Console.WriteLine("\nSUM OF COLS\n");
            colsum(a);
            if (rows == cols)
                sumdiagonal(a);
        }
    }
}
